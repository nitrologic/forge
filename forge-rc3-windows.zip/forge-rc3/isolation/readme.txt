a sandbox for foundry runs
run foundry run
